package com.example.electricitybillapp;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class DetailActivity extends AppCompatActivity {

    TextView textMonth, textUnits, textRebate, textTotal, textFinal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        textMonth = findViewById(R.id.textMonth);
        textUnits = findViewById(R.id.textUnits);
        textRebate = findViewById(R.id.textRebate);
        textTotal = findViewById(R.id.textTotal);
        textFinal = findViewById(R.id.textFinal);

        // Get data from Intent
        String month = getIntent().getStringExtra("month");
        int units = getIntent().getIntExtra("units", 0);
        double rebate = getIntent().getDoubleExtra("rebate", 0.0);
        double total = getIntent().getDoubleExtra("total", 0.0);
        double finalCost = getIntent().getDoubleExtra("final", 0.0);

        textMonth.setText("Month: " + month);
        textUnits.setText("Units: " + units + " kWh");
        textRebate.setText("Rebate: " + rebate + "%");
        textTotal.setText("Total Charges: RM " + String.format("%.2f", total));
        textFinal.setText("Final Cost: RM " + String.format("%.2f", finalCost));
    }
}
