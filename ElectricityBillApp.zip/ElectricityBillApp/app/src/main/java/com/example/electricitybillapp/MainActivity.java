package com.example.electricitybillapp;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import androidx.appcompat.widget.Toolbar;

public class MainActivity extends AppCompatActivity {

    EditText editTextMonth, editTextUnits, editTextRebate;
    TextView textViewTotal, textViewFinal;
    Button buttonCalculate, buttonSave, buttonAbout;
    ListView listViewRecords;
    DBHelper dbHelper;

    ArrayList<String> records = new ArrayList<>();
    ArrayAdapter<String> adapter;

    double totalCharges = 0.0;
    double finalCost = 0.0;

    int units = 0;
    double rebate = 0.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.mainToolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Electricity Bill Estimator");
        dbHelper = new DBHelper(this);

        editTextMonth = findViewById(R.id.editTextMonth);
        editTextUnits = findViewById(R.id.editTextUnits);
        editTextRebate = findViewById(R.id.editTextRebate);
        textViewTotal = findViewById(R.id.textViewTotal);
        textViewFinal = findViewById(R.id.textViewFinal);
        buttonCalculate = findViewById(R.id.buttonCalculate);
        buttonSave = findViewById(R.id.buttonSave);
        buttonAbout = findViewById(R.id.buttonAbout);
        listViewRecords = findViewById(R.id.listViewRecords);

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, records);
        listViewRecords.setAdapter(adapter);

        // ✅ About Button Click (Part F)
        buttonAbout.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AboutActivity.class);
            startActivity(intent);
        });

        // ✅ Part D: Clickable ListView to open DetailActivity
        listViewRecords.setOnItemClickListener((parent, view, position, id) -> {
            Cursor cursor = dbHelper.getAllBills();
            if (cursor.moveToPosition(position)) {
                String month = cursor.getString(1);
                int units = cursor.getInt(2);
                double rebate = cursor.getDouble(3);
                double total = cursor.getDouble(4);
                double finalCost = cursor.getDouble(5);

                Intent intent = new Intent(MainActivity.this, DetailActivity.class);
                intent.putExtra("month", month);
                intent.putExtra("units", units);
                intent.putExtra("rebate", rebate);
                intent.putExtra("total", total);
                intent.putExtra("final", finalCost);
                startActivity(intent);
            }
        });

        buttonCalculate.setOnClickListener(v -> {
            String sUnit = editTextUnits.getText().toString();
            String sRebate = editTextRebate.getText().toString();

            if (sUnit.isEmpty() || sRebate.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields!", Toast.LENGTH_SHORT).show();
                return;
            }

            units = Integer.parseInt(sUnit);
            rebate = Double.parseDouble(sRebate);

            totalCharges = calculateCharges(units);
            finalCost = totalCharges - (totalCharges * rebate / 100);

            textViewTotal.setText("Total Charges: RM " + String.format("%.2f", totalCharges));
            textViewFinal.setText("Final Cost: RM " + String.format("%.2f", finalCost));
        });

        buttonSave.setOnClickListener(v -> {
            String month = editTextMonth.getText().toString();

            if (month.isEmpty() || units == 0) {
                Toast.makeText(this, "Please enter all fields and calculate first", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean inserted = dbHelper.insertBill(month, units, rebate, totalCharges, finalCost);
            if (inserted) {
                Toast.makeText(this, "Saved to Database", Toast.LENGTH_SHORT).show();
                loadData(); // Refresh list view
            } else {
                Toast.makeText(this, "Failed to Save", Toast.LENGTH_SHORT).show();
            }
        });

        loadData(); // Load saved data on startup
    }

    private double calculateCharges(int units) {
        double total = 0;
        if (units <= 200) {
            total = units * 0.218;
        } else if (units <= 300) {
            total = (200 * 0.218) + ((units - 200) * 0.334);
        } else if (units <= 600) {
            total = (200 * 0.218) + (100 * 0.334) + ((units - 300) * 0.516);
        } else {
            total = (200 * 0.218) + (100 * 0.334) + (300 * 0.516) + ((units - 600) * 0.546);
        }
        return total;
    }

    public void loadData() {
        records.clear();
        Cursor cursor = dbHelper.getAllBills();
        if (cursor.moveToFirst()) {
            do {
                String month = cursor.getString(1);
                double finalCost = cursor.getDouble(5);
                records.add(month + " - RM " + String.format("%.2f", finalCost));
            } while (cursor.moveToNext());
        }
        adapter.notifyDataSetChanged();
    }
}


